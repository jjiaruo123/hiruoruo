# Reference: Canva Terms and Interface Elements

> **Status:** Planned. This glossary will be expanded after the how-to guides are stable.

## Glossary

| Term | Definition |
| --- | --- |
| Template | A ready-made layout with placeholder text, images, and colors that you can customize for your own design. |
| Canvas | The editable area in the center of the editor where the design is built. |
| Element | Any movable item on the canvas, such as a shape, line, sticker, icon, or photo. |
| Text box | A box that holds editable wording; select it to change the text, font, size, and color. |
| Uploads | The area where images and files from your own computer are stored and inserted into a design. |
| Element panel | The side panel that opens the library of shapes, photos, graphics, and other elements. |
| Share link | A web link that lets others view the design without signing in to edit it. |
| File format | The export type of a finished design, such as PNG, JPG, or PDF. |
| Pro element | A template, photo, or feature available only with a Canva Pro subscription; it is marked with a Pro badge. |

## Key Interface Elements

| Element | Location | Use |
| --- | --- | --- |
| Search bar | Top of the home page | Find templates by keyword, such as "poster" or "resume". |
| Editor toolbar | Top of the editor | Download, share, undo, and resize the design. |
| Side panel | Left side of the editor | Open templates, elements, uploads, and the photo library. |
| Text options bar | Appears when a text box is selected | Change font, size, color, alignment, and spacing. |
| Share button | Top-right corner of the editor | Download the design or copy a share link. |

## Related Guides

- [Quick Start](quickstart.md)
- [Troubleshooting](troubleshooting.md)
