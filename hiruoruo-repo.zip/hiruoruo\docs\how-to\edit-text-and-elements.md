# How to Edit Text and Elements

> **Status:** Planned. This outline will be expanded into a finished guide.

## Purpose

Complete Task 2: replace placeholder text, choose or upload images, and adjust shapes, colors, and fonts in the Canva editor.

## Reader Goal

The user finishes this guide with a personalized design: the text reads correctly, the images fit the layout, and the colors and fonts match the intended style.

## Prerequisites

- A template already open in the Canva editor (see [Start a Design from a Template](start-a-design-from-template.md)).
- For an uploaded image, the image file saved on your computer.

## Planned Steps

**Start:** Open your design in the Canva editor, and review the template layout before you change anything.

### Edit the text

1. Select a text box on the canvas.
2. Type your own wording to replace the placeholder text.
3. Use the font panel to choose a typeface, size, and color that stay easy to read.

### Add or replace images

1. Select the image you want to replace, then choose a new image from the photo library.
2. To use your own image, select **Uploads**, then **Upload files**, and choose the image from your computer.
3. Drag the image into place and resize it to fit the frame.

### Adjust shapes and elements

1. Select a shape, line, or sticker on the canvas to move or resize it.
2. Use the color panel to change the fill or outline color.
3. Remove any element you do not need by selecting it and pressing Delete.

**Condition:** If an element you want to use is marked with a Pro badge, choose a free element instead, or check whether your account already includes Pro access.

## Result Check

The design shows your own wording and images, no placeholder text remains, and every element sits within the canvas without overlapping the main text.

## Related Guides

- [Download and Share Your Design](download-and-share-your-design.md)
- [Reference Glossary](../reference.md)
