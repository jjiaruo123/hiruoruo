# Practice: Create a Private Repository with a README

This tutorial is the earlier GitHub practice exercise. It is kept here under `practice/` and is separate from the Canva project documentation.

## Prerequisites

- A GitHub account that you can sign into.
- Permission to create repositories in your account.
- A desktop web browser.

## Steps

1. Open your browser and sign in to github.com with your account.
2. In the top-right corner, click the plus (+) button and choose **New repository** from the dropdown menu.
3. In the **Repository name** field, type a name, for example `docs-practice`.
4. Under the visibility section, select the **Private** option.
5. Tick the box that says **Add a README file**.
6. Click the green **Create repository** button at the bottom of the page.

## Result Check

After you click **Create repository**, GitHub opens the page for the new repository. The repository name appears at the top, and the `README.md` file is listed in the file list with its content shown below.
