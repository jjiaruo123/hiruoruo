# How to Start a Design from a Template

> **Status:** Planned. This outline will be expanded into a finished guide.

## Purpose

Complete Task 1: sign in to Canva and start a new design from a suitable template.

## Reader Goal

The user finishes this guide with a template open in the Canva editor, ready to be personalized.

## Prerequisites

- A desktop browser and an internet connection.
- A Canva account, or an email address or phone number to create one.

## Planned Steps

**Start:** Open canva.com in a desktop browser, and decide what kind of design you need, such as a poster, social media post, or presentation.

1. Select **Sign in** and enter your account details, or select **Sign up** to create a new account.
2. In the search bar at the top, type a keyword that describes your design, such as "poster" or "Instagram post".
3. Browse the template results and select a layout that fits your purpose.
4. Select **Customize this template** to open it in the editor.
5. Check that the design size and orientation match what you need.

**Condition:** If the template you opened is the wrong size, return to the template library and choose a template for the correct format instead of resizing the current one.

## Result Check

The template appears in the editor, with its text, images, and layout visible on the canvas. The design name appears in the top bar.

## Related Guides

- [Edit Text and Elements](edit-text-and-elements.md)
- [Quick Start](../quickstart.md)
