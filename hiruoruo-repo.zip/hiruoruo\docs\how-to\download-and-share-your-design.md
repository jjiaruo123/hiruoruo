# How to Download and Share Your Design

> **Status:** Planned. This outline will be expanded into a finished guide.

## Purpose

Complete Task 3: export the finished Canva design in the right file format, or copy a share link for others to view.

## Reader Goal

The user finishes this guide with a downloadable file saved to their computer, or a share link they can send to others.

## Prerequisites

- A finished design open in the Canva editor (see [Edit Text and Elements](edit-text-and-elements.md)).
- Know whether the design will be posted online, printed, or sent as a document.

## Planned Steps

**Start:** Open your finished design in the Canva editor, and check that all text and images are in place.

### Download the design

1. Select **Share** in the top-right corner.
2. Select **Download**.
3. Choose a file format: PNG or JPG for online images, PDF for documents or printing.
4. Select **Download** again to save the file to your computer.

### Share a link

1. Select **Share** in the top-right corner.
2. Set the link access to **Anyone with the link can view**.
3. Select **Copy link**.
4. Paste the link into an email, message, or document to send it.

**Condition:** If the download includes a watermark or warns that a Pro element is required, replace that element with a free one before you export the design.

## Result Check

The exported file opens correctly on your computer, or the copied link opens the design in another browser. The colors and layout match what you saw in the editor.

## Related Guides

- [Edit Text and Elements](edit-text-and-elements.md)
- [Troubleshooting](../troubleshooting.md)
