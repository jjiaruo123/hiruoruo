# Troubleshooting

> **Status:** Planned. This page will be expanded after the how-to guides are stable.

## Common Problems and Fixes

### A template will not open in the editor

- Check that your browser is connected to the internet and updated to the latest version.
- Refresh the template page and select **Customize this template** again.
- If the editor still loads slowly, close other browser tabs and try again.

### An element or image you want is missing

- Use the search bar in the element panel to look for the item by keyword.
- Confirm the element is not filtered out by the category selected in the side panel.
- If you need your own image, upload it from your computer through **Uploads**.

### The download shows a watermark or a Pro warning

- Look through the design for any element marked with a Pro badge.
- Replace that element with a free template, photo, or shape.
- Export the design again after the Pro element is removed.

### A font looks different after downloading

- Check that the text box uses a font available in your region and account.
- If a font is unavailable, replace it with a standard free font in the text options bar.
- Re-download the design and compare the exported file with the editor view.

## Result Check

After applying a fix, repeat the action that failed: open a template, insert an element, or export the design. The action should complete without an error, and the item or file should appear in the expected place.

## Related Guides

- [Download and Share Your Design](how-to/download-and-share-your-design.md)
- [Reference Glossary](reference.md)
