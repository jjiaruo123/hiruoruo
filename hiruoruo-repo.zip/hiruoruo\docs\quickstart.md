# Quick Start: Make Your First Canva Design

> **Status:** Planned. This outline will be expanded into a finished guide.

## Purpose

Help a new user sign in to Canva, pick a template, and finish a first design in under ten minutes. This page condenses the first two core tasks; detailed steps are in the how-to guides under `docs/how-to/`.

## Reader Goal

By the end of this guide, the user has opened a template, changed the main text, and exported or shared the design.

## Prerequisites

- A computer with a desktop browser and an internet connection.
- An email address or a phone number to create a Canva account.

## Planned Steps

1. Open canva.com in your browser and sign in or create an account.
2. Search or browse the template library for a design that matches your purpose, such as a poster or social media post.
3. Open the template in the editor.
4. Replace the placeholder title with your own text.
5. Download the design as an image, or copy the share link.

## Result Check

Your own text appears on the design, and the finished design can be downloaded as a file or opened through the share link.

## Related Guides

- [Start a Design from a Template](how-to/start-a-design-from-template.md)
- [Edit Text and Elements](how-to/edit-text-and-elements.md)
